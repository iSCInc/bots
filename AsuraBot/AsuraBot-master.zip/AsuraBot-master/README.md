AsuraBot
========

A pywikibot running on dewiki. See the [user page](https://de.wikipedia.org/wiki/Benutzer:AsuraBot) on dewiki for up-to-date information.
